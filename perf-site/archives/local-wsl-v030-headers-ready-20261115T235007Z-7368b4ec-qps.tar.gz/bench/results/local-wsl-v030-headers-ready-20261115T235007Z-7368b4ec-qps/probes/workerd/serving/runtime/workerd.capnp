using Workerd = import "/workerd/workerd.capnp";
const worker :Workerd.Worker = (compatibilityDate = "2026-08-20", modules = [(name = "main", esModule = embed "bundle.mjs")]);
const config :Workerd.Config = (services = [(name = "bench", worker = .worker)], sockets = [(name = "http", address = "127.0.0.1:42109", http = (), service = "bench")]);
